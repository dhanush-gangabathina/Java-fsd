package com.ecommerce.tests;
public class UserAuthentication {

    private static final String VALID_USERNAME = "testUser";
    private static final String VALID_PASSWORD = "testPassword";

    public boolean authenticateUser(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            return false; 
        }

        return username.equals(VALID_USERNAME) && password.equals(VALID_PASSWORD);
    }
}
