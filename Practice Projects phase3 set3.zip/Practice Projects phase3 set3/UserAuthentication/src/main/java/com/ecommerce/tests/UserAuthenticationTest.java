package com.ecommerce.tests;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserAuthenticationTest {

    @Test
    public void testValidUserAuthentication() {
        UserAuthentication userAuthentication = new UserAuthentication();

        String username = "testUser";
        String password = "testPassword";
        assertTrue(userAuthentication.authenticateUser(username, password));
    }

    @Test
    public void testInvalidUserAuthentication() {
        UserAuthentication userAuthentication = new UserAuthentication();

        String username = "invalidUser";
        String password = "invalidPassword";

        assertFalse(userAuthentication.authenticateUser(username, password));
    }

    @Test
    public void testEmptyCredentials() {
        UserAuthentication userAuthentication = new UserAuthentication();
        String username = "";
        String password = "";

        assertFalse(userAuthentication.authenticateUser(username, password));
    }

}

