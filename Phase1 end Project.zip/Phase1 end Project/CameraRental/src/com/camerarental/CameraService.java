package com.camerarental;

public class CameraService {
    private String brand;
    private String model;
    private double perDayPrice;
    private boolean isRented;

    public CameraService(String brand, String model, double perDayPrice) {
        this.brand = brand;
        this.model = model;
        this.perDayPrice = perDayPrice;
        this.isRented = false;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPerDayPrice() {
        return perDayPrice;
    }

    public boolean isRented() {
        return isRented;
    }

    public void setRented(boolean rented) {
        isRented = rented;
    }

    @Override
    public String toString() {
        return brand + " " + model + " - " + perDayPrice;
    }
}
