package com;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FlipkartTest {
  WebDriver driver;
  
  @BeforeTest
  public void setUp() {
	  System.setProperty("webdriver.edge.driver","D:\\downloads\\msedgedriver.exe");
	  driver = new EdgeDriver();
	  driver.manage().window().maximize();
  }
  @Test(priority = 1)
  public void testPageLoadTime() {
	  driver.get("https://www.flipkart.com/");
	  long startTime = System.currentTimeMillis();
	  long endTime = System.currentTimeMillis();
	  long pageLoadTime = endTime - startTime;
      System.out.println("Page load time: " + pageLoadTime + " milliseconds");
      Assert.assertTrue(pageLoadTime < 5000, "Page load time exceeds 5 seconds");
 }
  @Test(priority =2)
  public void testSearchProduct() {
	  driver.get("https://www.flipkart.com/");
	  WebElement searchBox = driver.findElement(By.name("q"));
	  searchBox.sendKeys("iphone 13 Mobile");
	  searchBox.submit();
	  Assert.assertFalse(driver.getTitle().contains("iPhone 13 Mobile"),"Search results page not displayed");
  }
  @Test(priority = 3)
  public void testImageVisibility() {
	  WebElement lastVisibleImage = driver.findElement(By.xpath("//img[@class='_396cs4'][last()]"));
	  long windowHeight = (long) ((JavascriptExecutor) driver).executeScript("return window.innerHeight");
	  long imageBottomPosition = lastVisibleImage.getLocation().getY() + lastVisibleImage.getSize().getHeight();
	  Assert.assertTrue(imageBottomPosition <= windowHeight,"Image is not visible till screen height");
  }
  @Test(priority = 4)
  public void testScrollFeature() {
	  boolean isScrollable = (boolean) ((JavascriptExecutor) driver).executeScript("return document.documentElement.scrollHeight > document.documentElement.clientHeight"); 
	  Assert.assertTrue(isScrollable,"Page doen not have a scroll feature");
  }
  @Test(priority = 5)
  public void testContentRefresh() {
	  driver.get("https://www.flipkart.com/");
	  WebElement searchBox = driver.findElement(By.name("q"));
	  searchBox.sendKeys("iphone 13 Mobile");
	  searchBox.submit();
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	  long initialScrollHeight = (long) js.executeScript("return document.body.scrollHeight;");
	  js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	  try {
		  Thread.sleep(2000);
	  } catch (InterruptedException e) {
		  e.printStackTrace();
	  }
	  long finalScrollHeight = (long) js.executeScript("return document.body.scrollHeight;");
      long scrollHeightChange = finalScrollHeight - initialScrollHeight;
      Assert.assertFalse(scrollHeightChange > 0, "Content does not refresh while scrolling");
  }
 
  @Test(priority = 6)
  public void testNavigationToBottom() {
	  driver.get("https://www.flipkart.com/");
	  long initialScrollPosition = (long) ((JavascriptExecutor) driver).executeScript("return window.scrollY;");
	  ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");
	  long finalScrollPosition = (long) ((JavascriptExecutor) driver).executeScript("return window.scrollY;");
	  Assert.assertFalse(finalScrollPosition > initialScrollPosition, "Navigation to bottom of the page failed");
  }
  @Test(priority = 7)
  public void testBrowseCompatibility() {
	  driver.get("https://www.flipkart.com/");
	  WebElement searchBox = driver.findElement(By.name("q"));
      searchBox.sendKeys("iPhone 13 Mobile");
      searchBox.submit();
      JavascriptExecutor js = (JavascriptExecutor) driver;
      js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
      try {
          Thread.sleep(2000);
      } catch (InterruptedException e) {
          e.printStackTrace();
      }
      String currentPageSource = driver.getPageSource();
      Assert.assertEquals(driver.getTitle(), "IPhone 13 Mobile- Buy Products Online at Best Price in India - All Categories | Flipkart.com", "Page title is not as expected");
  }
  @AfterTest
  public void tearDown() {
	  if(driver != null) {
		  driver.quit();
	  }
  }
  
}
