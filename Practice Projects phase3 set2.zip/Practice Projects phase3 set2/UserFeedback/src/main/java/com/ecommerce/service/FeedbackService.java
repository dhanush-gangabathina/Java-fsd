package com.ecommerce.service;
import com.ecommerce.model.Feedback;

public interface FeedbackService {
    Feedback saveFeedback(Feedback feedback);
}
