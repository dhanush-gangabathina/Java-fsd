package ProjectSet3;
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class LinkedList {
    private Node head;

    public LinkedList() {
        this.head = null;
    }

    // Method to insert a new node at the end of the linked list
    private void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Method to delete the first occurrence of a key in the linked list
    private void deleteNode(int key) {
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        if (head.data == key) {
            head = head.next;
            return;
        }

        Node current = head;
        Node prev = null;

        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }

        prev.next = current.next;
    }

    // Method to display the linked list
    private void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

        // Insert elements into the linked list
        linkedList.insert(10);
        linkedList.insert(20);
        linkedList.insert(30);
        linkedList.insert(40);

        System.out.println("Original Linked List:");
        linkedList.display();

        // Delete the first occurrence of a key
        int keyToDelete = 20;
        linkedList.deleteNode(keyToDelete);

        System.out.println("Linked List after deleting the first occurrence of " + keyToDelete + ":");
        linkedList.display();
    }
}
