package ProjectSet3;

import java.util.Arrays;

public class RightRotateArray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int steps = 5;

        System.out.println("Original Array: " + Arrays.toString(array));

        rightRotateArray(array, steps);

        System.out.println("Array after right rotation by " + steps + " steps: " + Arrays.toString(array));
    }

    private static void rightRotateArray(int[] array, int steps) {
        int n = array.length;
        steps = steps % n; 
        reverseArray(array, 0, n - 1);
        reverseArray(array, 0, steps - 1);
        reverseArray(array, steps, n - 1);
    }
    private static void reverseArray(int[] array, int start, int end) {
        while (start < end) {
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;
            start++;
            end--;
        }
    }
}
