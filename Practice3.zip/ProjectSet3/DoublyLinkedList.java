package ProjectSet3;
class Node3 {
    int data;
    Node3 prev;
    Node3 next;

    Node3(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

public class DoublyLinkedList {
    private Node3 head;

    public DoublyLinkedList() {
        this.head = null;
    }
    private void insert(int data) {
        Node3 newNode = new Node3(data);

        if (head == null) {
            head = newNode;
        } else {
            Node3 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }
    private void traverseForward() {
        Node3 current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
    private void traverseBackward() {
        Node3 current = head;
        while (current.next != null) {
            current = current.next;
        }
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();
        doublyList.insert(10);
        doublyList.insert(20);
        doublyList.insert(30);
        doublyList.insert(40);

        System.out.println("Doubly Linked List (Forward):");
        doublyList.traverseForward();

        System.out.println("Doubly Linked List (Backward):");
        doublyList.traverseBackward();
    }
}
