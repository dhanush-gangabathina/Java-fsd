package ProjectSet3;
class Node2 {
    int data;
    Node next;

    Node2(int data) {
        this.data = data;
        this.next = null;
    }
}

public class SortedCircularLinkedList {
    private Node head;

    public SortedCircularLinkedList() {
        this.head = null;
    }
    private void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            head.next = head; // Circular reference to itself
        } else if (data <= head.data) {
            newNode.next = head;
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }
    private void display() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
        SortedCircularLinkedList circularList = new SortedCircularLinkedList();
        circularList.insert(10);
        circularList.insert(20);
        circularList.insert(30);
        circularList.insert(15);
        System.out.println("Sorted Circular Linked List:");
        circularList.display();
    }
}
