package ProjectSet3;
import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedList = {12, 5, 1, 7, 9, 20, 15, 4, 8, 11};

        int fourthSmallest = findFourthSmallestElement(unsortedList);

        System.out.println("Original List: " + Arrays.toString(unsortedList));
        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }

    private static int findFourthSmallestElement(int[] array) {
        if (array.length < 4) {
            System.out.println("List does not have at least four elements.");
            return -1; 
        }

        Arrays.sort(array);

        return array[3]; 
    }
}
