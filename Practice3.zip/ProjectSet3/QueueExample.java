package ProjectSet3;
import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();
        System.out.println("Enqueuing elements into the queue:");
        for (int i = 1; i <= 5; i++) {
            queue.add(i);
            System.out.println("Enqueued: " + i);
        }

        System.out.println("Queue after enqueuing elements: " + queue);
        System.out.println("\nDequeuing elements from the queue:");
        while (!queue.isEmpty()) {
            int dequeuedElement = queue.poll();
            System.out.println("Dequeued: " + dequeuedElement);
        }
        System.out.println("Queue after dequeuing elements: " + queue);
    }
}
