package ProjectSet3;
import java.util.Scanner;

public class SumInRange {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the array (n): ");
        int n = scanner.nextInt();

        int[] array = new int[n];

        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + i + ": ");
            array[i] = scanner.nextInt();
        }

        System.out.print("Enter the value of L (0 <= L <= R <= n-1): ");
        int L = scanner.nextInt();

        System.out.print("Enter the value of R (0 <= L <= R <= n-1): ");
        int R = scanner.nextInt();

        if (isValidRange(n, L, R)) {
            int sumInRange = calculateSumInRange(array, L, R);
            System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sumInRange);
        } else {
            System.out.println("Invalid range. Please make sure 0 <= L <= R <= n-1");
        }

        scanner.close();
    }

    private static boolean isValidRange(int n, int L, int R) {
        return (L >= 0 && R < n && L <= R);
    }

    private static int calculateSumInRange(int[] array, int L, int R) {
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += array[i];
        }
        return sum;
    }
}

