package com.healthlogger.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.healthlogger.entity.Patient;
/**
 * Servlet implementation class RecordVitalsServlet
 */
@WebServlet("/RecordVitalsServlet")
public class RecordVitalsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public RecordVitalsServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long patientId = Long.parseLong(request.getParameter("patientId"));
        String bpLow = request.getParameter("bpLow");
        String bpHigh = request.getParameter("bpHigh");
        String spo2 = request.getParameter("spo2");

        // Perform the logic to record vitals for the patient in the database
        recordVitals(patientId, bpLow, bpHigh, spo2);

        // Redirect to the View Patients page
        response.sendRedirect("viewPatientsServlet");
        response.sendRedirect("vitalsDetailsServlet");

    }

    private void recordVitals(long patientId, String bpLow, String bpHigh, String spo2) {
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();

            // Retrieve the patient from the database
            Patient patient = session.get(Patient.class, patientId);
            session.update(patient);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace(); // Handle the exception appropriately
        } finally {
            session.close();
            sessionFactory.close();
	}
    }
}

