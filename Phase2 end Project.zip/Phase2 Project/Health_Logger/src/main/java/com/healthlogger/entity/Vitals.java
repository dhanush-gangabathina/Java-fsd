package com.healthlogger.entity;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
public class Vitals implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Sr_No;
    private String bpLow;
    private String bpHigh;
    private String spo2;

    @Temporal(TemporalType.TIMESTAMP)
    private Date recordedOn;

    @ManyToOne
    @JoinColumn(name = "patient_id")
    private Patient patient;

    

    public Vitals(int Sr_No, String bpLow, String bpHigh, String spo2, Date recordedOn) {
		super();
		this.bpLow = bpLow;
		this.bpHigh = bpHigh;
		this.spo2 = spo2;
		this.recordedOn = recordedOn;
		
	}

	

	public String getBpLow() {
		return bpLow;
	}

	public void setBpLow(String bpLow) {
		this.bpLow = bpLow;
	}

	public String getBpHigh() {
		return bpHigh;
	}

	public void setBpHigh(String bpHigh) {
		this.bpHigh = bpHigh;
	}

	public String getSpo2() {
		return spo2;
	}

	public void setSpo2(String spo2) {
		this.spo2 = spo2;
	}

	public Date getRecordedOn() {
		return recordedOn;
	}

	public void setRecordedOn(Date recordedOn) {
		this.recordedOn = recordedOn;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Vitals() {
        this.recordedOn = new Date();
    }

    public Vitals(String bpLow, String bpHigh, String spo2) {
        this();
        this.bpLow = bpLow;
        this.bpHigh = bpHigh;
        this.spo2 = spo2;
    }}
