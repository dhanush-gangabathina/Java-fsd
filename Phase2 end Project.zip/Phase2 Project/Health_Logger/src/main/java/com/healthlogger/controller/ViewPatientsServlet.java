package com.healthlogger.controller;
import com.healthlogger.entity.Patient;
import java.util.List;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class ViewPatientsServlet
 */
@WebServlet("/ViewPatientsServlet")
public class ViewPatientsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ViewPatientsServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Patient> patients;

        String patientName = request.getParameter("patientName");{
        if (patientName != null && !patientName.isEmpty()) {
            patients = searchPatientsByName(patientName);
        } else {
            patients = getPatientsFromDatabase();
        }

        request.setAttribute("patients", patients);

        request.getRequestDispatcher("viewPatients.jsp").forward(request, response);
}
	}
		

	    private List<Patient> getPatientsFromDatabase() {
	        Configuration configuration = new Configuration().configure();
	        SessionFactory sessionFactory = configuration.buildSessionFactory();
	        Session session = sessionFactory.openSession();

	        try {
	            // Retrieve the list of patients from the database
	            return session.createQuery("FROM Patient", Patient.class).list();
	        } finally {
	            session.close();
	            sessionFactory.close();
	        }
	    }
	    

	    private List<Patient> searchPatientsByName(String patientName) {
	        Configuration configuration = new Configuration().configure();
	        SessionFactory sessionFactory = configuration.buildSessionFactory();
	        Session session = sessionFactory.openSession();

	        try {
	            // Retrieve the list of patients matching the given name from the database
	            return session.createQuery("FROM Patient WHERE name LIKE :name", Patient.class)
	                    .setParameter("name", "%" + patientName + "%")
	                    .list();
	        } finally {
	            session.close();
	            sessionFactory.close();
	        }
	 }
}
