package com.healthlogger.dao;

import java.util.List;

import com.healthlogger.entity.Patient;

public interface PatientDao {
	void addPatient(Patient patient);

    List<Patient> getAllPatients();
}
