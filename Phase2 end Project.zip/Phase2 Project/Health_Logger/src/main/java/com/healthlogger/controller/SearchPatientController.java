package com.healthlogger.controller;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.healthlogger.entity.Patient;
/**
 * Servlet implementation class SearchPatientController
 */
@WebServlet("/SearchPatientController")
public class SearchPatientController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private final SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();

    /**
     * Default constructor. 
     */
    public SearchPatientController() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 try (Session session = sessionFactory.openSession()) {
	            session.beginTransaction();

	            long patientId = Long.parseLong(request.getParameter("id"));
	            Patient patient = session.get(Patient.class, patientId);

	            request.setAttribute("patient", patient);

	            session.getTransaction().commit();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        request.getRequestDispatcher("searchPatient.jsp").forward(request, response);	
	        }
	}


