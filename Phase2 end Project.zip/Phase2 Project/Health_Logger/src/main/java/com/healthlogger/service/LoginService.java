package com.healthlogger.service;
import com.healthlogger.dao.LoginDao;
import com.healthlogger.entity.Login;

public class LoginService {

	LoginDao ld = new LoginDao();
	public String signIn(Login login) {
		if(ld.signIn(login)>0) {
			return "Successfully login";
		}else {
			return "Failure try once again";
		}
	}
}
