package com.healthlogger.controller;

import java.io.IOException;
import java.io.PrintWriter;

import com.healthlogger.entity.Login;
import com.healthlogger.service.LoginService;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LoginController() {
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		Login login = new Login();
		login.setEmail(email);
		login.setPassword(password);
		
		HttpSession hs = request.getSession();
		
		RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
		LoginService ls = new LoginService();
		String result = ls.signIn(login);
		if(result.equalsIgnoreCase("Successfully login")) {
				hs.setAttribute("admin", true);
				response.sendRedirect("adminHome.jsp");
		}else {
			pw.println("failure try once again");
			rd.include(request, response);
		}
		
		response.setContentType("text/html");
	}
	}

