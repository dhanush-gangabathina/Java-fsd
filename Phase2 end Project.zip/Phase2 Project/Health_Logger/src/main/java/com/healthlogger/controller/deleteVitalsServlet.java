package com.healthlogger.controller;
import com.healthlogger.entity.Vitals;
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class deleteVitalsServlet
 */
@WebServlet("/deleteVitalsServlet")
public class deleteVitalsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public deleteVitalsServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 long vitalsId = Long.parseLong(request.getParameter("vitalsId"));

	        // Perform the logic to delete vitals from the database
	        deleteVitals(vitalsId);

	        // Redirect back to the Vitals Details page
	        response.sendRedirect("vitalsDetailsServlet");
	    }

	    private void deleteVitals(long vitalsId) {
	        Configuration configuration = new Configuration().configure();
	        SessionFactory sessionFactory = configuration.buildSessionFactory();
	        Session session = sessionFactory.openSession();
	        Transaction transaction = null;

	        try {
	            transaction = session.beginTransaction();

	            // Retrieve the vitals from the database
	            Vitals vitals = session.get(Vitals.class, vitalsId);

	            // Delete the vitals entity
	            session.delete(vitals);

	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace(); // Handle the exception appropriately
	        } finally {
	            session.close();
	            sessionFactory.close();
	        }
	}

}
