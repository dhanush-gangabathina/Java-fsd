package com.healthlogger.controller;
import com.healthlogger.entity.Patient;
import com.healthlogger.entity.Vitals;
import java.util.List;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class vitalsDetailsServlet
 */
@WebServlet("/vitalsDetailsServlet")
public class vitalsDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public vitalsDetailsServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("vitals accessed");
		List<Vitals> vitalsList = getVitalsFromDatabase();
		System.out.println("vitalslist"+vitalsList.size());
		if (!vitalsList.isEmpty()) {
	        Vitals firstVitals = vitalsList.get(0);
	        Patient patient = firstVitals.getPatient();
	        
	        if (patient != null) {
	            System.out.println("Patient Name: " + patient.getName());
	            System.out.println("Patient Email: " + patient.getEmail());
	        	System.out.println("Patient Age: "+ patient.getAge());
	        	System.out.println("Patient Gender: "+ patient.getGender());
	        	System.out.println("Patient Phone: "+ patient.getPhone());
	        	System.out.println("Patient Diagnosis: "+ patient.getDiagnosis());
	        	System.out.println("Patient Remark: "+ patient.getRemark());

	        }
	    }
        request.setAttribute("vitalsList", vitalsList);
        
        request.getRequestDispatcher("vitalsDetails.jsp").forward(request, response);
    }

    private List<Vitals> getVitalsFromDatabase() {
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();

        try {
            return session.createQuery("FROM Vitals", Vitals.class).list();
        } finally {
            session.close();
            sessionFactory.close();
        }	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
