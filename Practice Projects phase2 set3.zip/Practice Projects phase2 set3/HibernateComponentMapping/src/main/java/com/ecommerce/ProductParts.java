package com.ecommerce;

public class ProductParts {

}
