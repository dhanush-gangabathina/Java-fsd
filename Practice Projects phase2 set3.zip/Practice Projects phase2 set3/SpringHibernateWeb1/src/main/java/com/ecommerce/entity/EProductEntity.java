package com.ecommerce.entity;

public class EProductEntity {

}
