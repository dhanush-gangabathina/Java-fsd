package Project;

 class Practice3 {
	synchronized void Practice3(int x) {
		for(int i=1;i<=5;i++) {
			System.out.println(x*i);
			try {
				Thread.sleep(400);
			}
			catch(Exception ex) {
				System.out.println(ex);
			}
		}
	}
}
 class Thread1 extends Thread{
	 Practice3 pp3;
	 Thread1(Practice3 pp3){
		 this.pp3 = pp3;
	 }
	 public void run() {
		 pp3.Practice3(2);
	 }
 }
	 class Thread2 extends Thread{
		 Practice3 p3;
		 Thread2(Practice3 p3){
			 this.p3 = p3;
		 }
		 public void run() {
			 p3.Practice3(5);
		 }
	 }
class PracticeProject3{
	public static void main(String[] args) {
		Practice3 obj = new Practice3();
		Thread1 t1 = new Thread1(obj);
		Thread2 t2 = new Thread2(obj);
		t1.start();
		t2.start();
	}
}

