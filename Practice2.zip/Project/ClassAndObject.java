package Project;
import java.util.Scanner;
class ClassAndObject {
	 String name;
	 int roll_no;
	 void input() {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter name ");
		 name=sc.nextLine();
		 System.out.println("Enter roll_no ");
		 roll_no = sc.nextInt();
	 }
	 void show() {
		 System.out.println("Name "+name);
		 System.out.println("roll_no "+roll_no);
	 }
	public static void main(String args[]) {
		ClassAndObject co = new ClassAndObject();
		co.input();
		co.show();
	}
	}