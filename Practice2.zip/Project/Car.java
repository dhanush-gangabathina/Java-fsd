package Project;

public class Car {
	int wheel;
	String colour;
	float price;
	
	void start() {
		System.out.println("Car Stated...");
	}
	
	void appliedGear(int gr) {
		System.out.println("Your applied "+gr+" Gear ");
	}
	
	void moving(int speed) {
		System.out.println("Car is moving with speed as "+speed+" Km/hr");
	}
	void stop() {
		System.out.println("Car stop");
	}
	void setCarInfo(int wheel, String colour,float price) {
		this.wheel=wheel;
		this.colour=colour;
		this.price=price;
	}
	void displayCarInfo(String name) {
		String msg="Car Info";		// local variable 
		System.out.println(msg+" : "+name);
		System.out.println("Wheel "+wheel);
		System.out.println("Colour "+colour);
		System.out.println("Price "+price);
	}
	Car() {
		System.out.println("object created...");
		this.wheel=4;
		this.price=600000;
		this.colour="Unknown";
	}
	// parameter consructor 
	Car(int wheel, String colour,float price) {
		this.wheel=wheel;	// this.wheel is instance and wheel is local 
		this.colour=colour;
		this.price=price;
	}
}

