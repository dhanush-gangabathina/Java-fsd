package Project;

interface First 
{  
    default void show() 
    { 
        System.out.println("First Interface"); 
    } 
} 
interface Second 
{  
    default void show() 
    { 
        System.out.println("Second Interface"); 
    } 
}  
public class Diamond implements First, Second 
{  
    public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
        Diamond dm = new Diamond(); 
        dm.show(); 
    } 
}
