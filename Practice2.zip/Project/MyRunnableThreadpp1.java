package Project;

public class MyRunnableThreadpp1 implements Runnable{
	public static int myCount = 0;
	public MyRunnableThreadpp1() {
		
	}
	public void run() {
		while(MyRunnableThreadpp1.myCount <= 10) {
			try {
				System.out.println("Expl Thread:"+(++MyRunnableThreadpp1.myCount));
				Thread.sleep(100);
			}
			catch(InterruptedException iex) {
				System.out.println("Excetion in Thread:"+iex.getMessage());
			}
		}
	}

	public static void main(String[] args) {
		System.out.println("Starting Main Thread");
		MyRunnableThreadpp1 mrtpp1 = new MyRunnableThreadpp1();
		Thread t = new Thread(mrtpp1);
		t.start();
		while(MyRunnableThreadpp1.myCount <= 10) {
			try {
				System.out.println("Main Thread:"+(++MyRunnableThreadpp1.myCount));
				Thread.sleep(100);
			}
			catch(InterruptedException iex) {
				System.out.println("Exception in main thread:"+iex.getMessage());
			}
		}
		System.out.println("End of Mian Thread");
	}

}
