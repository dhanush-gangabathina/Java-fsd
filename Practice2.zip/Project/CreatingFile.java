package Project;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
public class CreatingFile {

	public static void main(String[] args) {
		try {
			File file = new File("Demo File.txt");
			if(!file.exists()) {
				file.createNewFile();
			}
			PrintWriter pw = new PrintWriter(file);
			pw.println("I have created a file using java program");
			pw.close();
			System.out.println("DOne");
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

}
