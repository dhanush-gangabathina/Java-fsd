package Project;

public class CustomException extends Exception 
{ 
    public CustomException(String s) 
    { 
        super(s); 
    } 
} 
class Main 
{ 
    public static void main(String args[]) 
    { 
        try
        { 
            throw new CustomException("temporary"); 
        } 
        catch (CustomException ex) 
        { 
            System.out.println("Caught"); 
            System.out.println(ex.getMessage()); 
        } 
    } 
}
