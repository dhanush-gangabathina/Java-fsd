package Project;

public class CarTest {

	public static void main(String[] args) {
		Car innova = new Car();	
		innova.displayCarInfo("Innova");
		Car ertiga = new Car();
		ertiga.setCarInfo(4, "Gray", 1300000);
		ertiga.setCarInfo(4, "Gray", 1800000);
		ertiga.setCarInfo(4, "Gray", 1500000);
		ertiga.displayCarInfo("Ertiga");
		Car bmw  = new Car(4,"Black",10000000);	// parameter constructor 
		bmw.displayCarInfo("BMW");
		}

	}
