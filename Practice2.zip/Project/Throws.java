package Project;

class Throws {
	void div(int a,int b) throws ArithmeticException {
		if(b==0) {
			throw new ArithmeticException();
		}
		else {
			int c=a/b;
			System.out.println(c);
		}
	}

	public static void main(String[] args) {
		Throws t = new Throws();
		try {
			t.div(20, 0);
		}
		catch(Exception e) { 
			System.out.println("the value of b is zero");
		}		
	}

}
