package Project;

public class PracticeProject2 {

	public static void main(String[] args) {
		PracticeProject2 pp2 = new PracticeProject2();
		System.out.println("Hi");
		PracticeProject2.timeA();
	System.out.println("Hello");
	PracticeProject2.timeB();
	System.out.println("Bye");
		
	}
	public static void timeA() {
		try {
			Thread.sleep(500);
		}
		catch(Exception e) {
			
		}
	}
	public static void timeB() {
		try {
			Thread.sleep(1000);
		}
		catch(Exception e) {
			
		}
	}

}
