package Project;

public class PracticeProject1 extends Thread{
	public void run() {
		System.out.println("Thread running");
	}

	public static void main(String[] args) {
		PracticeProject1 pp1 = new PracticeProject1();
		pp1.start();
	}

}
