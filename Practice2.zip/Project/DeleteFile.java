package Project;
import java.io.File;
public class DeleteFile {

	public static void main(String[] args) {
		File myFile = new File("C:\\Users\\Dhanush\\Practice Projects set 2\\AssistedProject\\To delete.txt");
		if(myFile.delete()) {
			System.out.println("File deleted: "+myFile.getName()+ " Successfully");
		}
		else {
			System.out.println("Failed to delete");
		}
	}

}
