package Project;
import java.io.FileWriter;
import java.io.IOException;
public class UpdateFile {

	public static void main(String[] args) {
		String data = "This is line is added";
		try {
			FileWriter output = new FileWriter("C:\\Users\\Dhanush\\Practice Projects set 2\\AssistedProject\\To Read.txt",true);
			output.write(data);
			System.out.println("Data appended successfully");
			output.close();
		}
		catch (IOException e) {
			System.out.println("File update error");
		}
	}

}
