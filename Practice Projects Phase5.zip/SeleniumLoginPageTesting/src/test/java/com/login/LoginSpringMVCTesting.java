package com.login;

import org.testng.annotations.Test;

public class LoginSpringMVCTesting {
  @Test
  public void f() {
  }
}
