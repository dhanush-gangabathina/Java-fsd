package com.example.test;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Arrays;
import java.util.List;

public class CustomUserDetailsService implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // For simplicity, using an in-memory user store
        List<UserDetails> users = Arrays.asList(
                User.withUsername("user123")
                        .password("{bcrypt}$2a$10$5t4zhXZTTtNG0JSJnH1Z5ue/8oVT.QDnMjFEydctfXWYdd/6.2aTm")
                        .roles("USER")
                        .build()
        );

        return users.stream()
                .filter(userDetails -> userDetails.getUsername().equals(username))
                .findFirst()
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    }
}
