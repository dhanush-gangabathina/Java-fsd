package Projects;
import java.util.ArrayList;
import java.util.List;
public class PracticeProject5 {

	public static void main(String[] args) {
		runTests();
	}
		 private static void runTests() {
		        List<String> list = new ArrayList<>();
		        list.add("One");
		        list.add("Two");
		        list.add("Three");
		        System.out.println("Element at index 0: " + list.get(0));
		        System.out.println("Element at index 1: " + list.get(1));
		        System.out.println("Element at index 2: " + list.get(2));
		        System.out.println("Iterating through the list:");
		        for (String element : list) {
		            System.out.println(element);
		        }
		        list.remove("Two");
		        System.out.println("List after removing 'Two': " + list);
		        verifyResults(list);
		    }
		    private static void verifyResults(List<String> list) {
	}
}


