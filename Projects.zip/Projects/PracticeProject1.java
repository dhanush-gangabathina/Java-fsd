package Projects;

public class PracticeProject1 {

	public static void main(String[] args) {
		char c= 'D';
		int i= c; //Implicit Type Casting
		System.out.println(i);
		
		float b=18.7f;
		int d=  (int) b;
		System.out.println(d);
	}

}  
