package Projects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class PracticeProject10 {

	public static void main(String[] args) {
		String inputStr = "My name is Dhanush. Iam 22 years old. All of my friends call me Dhanush";
		String regexStr = "Dhanush";
		String replacingStr = "Kumar";
		Pattern pattern = Pattern.compile(regexStr, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(inputStr);
		String outputStr = matcher.replaceFirst(replacingStr);
		System.out.println(outputStr);
		String outputStr1 = matcher.replaceAll(replacingStr);
		System.out.println(outputStr1);

	}

}
