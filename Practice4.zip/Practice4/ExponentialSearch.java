package Practice4;
import java.util.Scanner;
import java.util.Arrays;

public class ExponentialSearch {
    public static int exponentialSearch(int[] arr, int key) {
        int size = arr.length;
                if (arr[0] == key) {
            return 0;
        }
        int i = 1;
        while (i < size && arr[i] <= key) {
            i *= 2;
        }
        return Arrays.binarySearch(arr, i / 2, Math.min(i, size), key);
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the sorted array: ");
        int size = scanner.nextInt();
        int[] array = new int[size];
        System.out.println("Enter the sorted elements of the array:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }
        System.out.print("Enter the element to search: ");
        int key = scanner.nextInt();
        int result = exponentialSearch(array, key);
        if (result >= 0) {
            System.out.println("Element found at index: " + result);
        } else {
            System.out.println("Element not found in the array.");
        }
        scanner.close();
    }
}
